import { defineStore } from 'pinia';
import api from '../api';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    token: localStorage.getItem('token'),
    isAuthenticated: false
  }),
  
  actions: {
    async signIn(credentials) {
      try {
        const { data } = await api.post('/auth/login', credentials);
        this.user = data.user;
        this.token = data.token;
        this.isAuthenticated = true;
        localStorage.setItem('token', data.token);
        return data;
      } catch (error) {
        throw error.response?.data || error.message;
      }
    },
    
    async signUp(userData) {
      try {
        const { data } = await api.post('/auth/register', userData);
        this.user = data.user;
        this.token = data.token;
        this.isAuthenticated = true;
        localStorage.setItem('token', data.token);
        return data;
      } catch (error) {
        throw error.response?.data || error.message;
      }
    },
    
    logout() {
      this.user = null;
      this.token = null;
      this.isAuthenticated = false;
      localStorage.removeItem('token');
    }
  }
});