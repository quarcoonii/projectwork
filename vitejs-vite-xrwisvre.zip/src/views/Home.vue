<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

const navigateToSignIn = () => {
  router.push('/signin');
};

const navigateToSignUp = () => {
  router.push('/signup');
};
</script>

<template>
  <div class="min-h-screen flex flex-col items-center justify-center bg-gray-50">
    <div class="max-w-2xl w-full text-center space-y-8">
      <h1 class="text-4xl font-bold text-gray-900">
        GradConnect
      </h1>
      <p class="text-xl text-gray-600">
        Empowering graduate research through intelligent collaboration
      </p>
      
      <div class="flex gap-4 justify-center">
        <button
          @click="navigateToSignIn"
          class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Sign In
        </button>
        <button
          @click="navigateToSignUp"
          class="px-6 py-3 bg-white text-blue-600 border-2 border-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
        >
          Sign Up
        </button>
      </div>
    </div>
  </div>
</template>