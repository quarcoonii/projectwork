<script setup>
import AISearchBar from '../components/AISearchBar.vue';
import Chat from '../components/Chat.vue';
</script>

<template>
  <div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-6">Student Dashboard</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="space-y-6">
        <div class="bg-white p-6 rounded-lg shadow">
          <h2 class="text-xl font-semibold mb-4">AI Research Assistant</h2>
          <AISearchBar />
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow">
          <h2 class="text-xl font-semibold mb-4">Supervisor Chat</h2>
          <Chat />
        </div>
      </div>
      
      <div class="bg-white p-6 rounded-lg shadow">
        <h2 class="text-xl font-semibold mb-4">Thesis Progress</h2>
        <!-- Add thesis progress tracking components here -->
      </div>
    </div>
  </div>
</template>