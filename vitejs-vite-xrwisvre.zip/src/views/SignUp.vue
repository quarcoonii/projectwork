<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth';

const router = useRouter();
const authStore = useAuthStore();

const userData = ref({
  name: '',
  email: '',
  password: '',
  role: 'student'
});

const signUp = async () => {
  try {
    await authStore.signUp(userData.value);
    router.push(userData.value.role === 'student' ? '/student-dashboard' : '/supervisor-dashboard');
  } catch (error) {
    console.error('Sign up error:', error);
  }
};
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-50">
    <div class="max-w-md w-full space-y-8 p-8 bg-white rounded-xl shadow-lg">
      <h2 class="text-3xl font-bold text-center">Sign Up</h2>
      
      <form @submit.prevent="signUp" class="mt-8 space-y-6">
        <div>
          <label class="block text-sm font-medium text-gray-700">Name</label>
          <input
            v-model="userData.name"
            type="text"
            required
            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700">Email</label>
          <input
            v-model="userData.email"
            type="email"
            required
            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700">Password</label>
          <input
            v-model="userData.password"
            type="password"
            required
            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700">Role</label>
          <select
            v-model="userData.role"
            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="student">Student</option>
            <option value="supervisor">Supervisor</option>
          </select>
        </div>
        
        <button
          type="submit"
          class="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
        >
          Sign Up
        </button>
      </form>
    </div>
  </div>
</template>