<script setup>
import { ref } from 'vue';

const searchQuery = ref('');
const searchResults = ref([]);

const performSearch = async () => {
  // TODO: Implement AI-powered search
  searchResults.value = ['Sample result 1', 'Sample result 2'];
};
</script>

<template>
  <div class="w-full max-w-2xl mx-auto">
    <div class="relative">
      <input
        v-model="searchQuery"
        @keyup.enter="performSearch"
        type="text"
        placeholder="Ask AI about thesis writing..."
        class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
      <button
        @click="performSearch"
        class="absolute right-2 top-1/2 transform -translate-y-1/2 px-4 py-1 bg-blue-500 text-white rounded-md"
      >
        Search
      </button>
    </div>
    
    <div v-if="searchResults.length" class="mt-4">
      <div v-for="(result, index) in searchResults" :key="index" class="p-2 border-b">
        {{ result }}
      </div>
    </div>
  </div>
</template>