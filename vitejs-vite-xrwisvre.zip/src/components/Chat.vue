<script setup>
import { ref } from 'vue';

const messages = ref([]);
const newMessage = ref('');

const sendMessage = () => {
  if (newMessage.value.trim()) {
    messages.value.push({
      id: Date.now(),
      text: newMessage.value,
      sender: 'user',
      timestamp: new Date()
    });
    newMessage.value = '';
  }
};
</script>

<template>
  <div class="flex flex-col h-[500px] border rounded-lg">
    <div class="flex-1 overflow-y-auto p-4">
      <div
        v-for="message in messages"
        :key="message.id"
        :class="[
          'mb-4 p-2 rounded-lg max-w-[80%]',
          message.sender === 'user'
            ? 'ml-auto bg-blue-500 text-white'
            : 'bg-gray-200'
        ]"
      >
        {{ message.text }}
        <div class="text-xs mt-1 opacity-70">
          {{ new Date(message.timestamp).toLocaleTimeString() }}
        </div>
      </div>
    </div>
    
    <div class="border-t p-4">
      <div class="flex gap-2">
        <input
          v-model="newMessage"
          @keyup.enter="sendMessage"
          type="text"
          placeholder="Type your message..."
          class="flex-1 px-3 py-2 border rounded-lg"
        />
        <button
          @click="sendMessage"
          class="px-4 py-2 bg-blue-500 text-white rounded-lg"
        >
          Send
        </button>
      </div>
    </div>
  </div>
</template>