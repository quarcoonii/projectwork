import express from 'express';
import { auth, checkRole } from '../middleware/auth.js';
import User from '../models/User.js';

const router = express.Router();

router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching profile', error: error.message });
  }
});

router.get('/supervisors', auth, async (req, res) => {
  try {
    const supervisors = await User.find({ role: 'supervisor' }).select('-password');
    res.json(supervisors);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching supervisors', error: error.message });
  }
});

export default router;