import express from 'express';
import { auth } from '../middleware/auth.js';
import Chat from '../models/Chat.js';

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const chat = new Chat({
      participants: [req.user.userId, req.body.participantId],
      thesis: req.body.thesisId
    });
    await chat.save();
    res.status(201).json(chat);
  } catch (error) {
    res.status(500).json({ message: 'Error creating chat', error: error.message });
  }
});

router.post('/:chatId/messages', auth, async (req, res) => {
  try {
    const chat = await Chat.findById(req.params.chatId);
    if (!chat) {
      return res.status(404).json({ message: 'Chat not found' });
    }
    
    chat.messages.push({
      sender: req.user.userId,
      content: req.body.content
    });
    
    await chat.save();
    res.status(201).json(chat);
  } catch (error) {
    res.status(500).json({ message: 'Error sending message', error: error.message });
  }
});

router.get('/user', auth, async (req, res) => {
  try {
    const chats = await Chat.find({ participants: req.user.userId })
      .populate('participants', 'name email')
      .populate('thesis', 'title');
    res.json(chats);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching chats', error: error.message });
  }
});

export default router;