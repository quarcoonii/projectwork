import express from 'express';
import { auth, checkRole } from '../middleware/auth.js';
import Thesis from '../models/Thesis.js';

const router = express.Router();

router.post('/', auth, checkRole(['student']), async (req, res) => {
  try {
    const thesis = new Thesis({
      ...req.body,
      student: req.user.userId
    });
    await thesis.save();
    res.status(201).json(thesis);
  } catch (error) {
    res.status(500).json({ message: 'Error creating thesis', error: error.message });
  }
});

router.get('/student/:studentId', auth, async (req, res) => {
  try {
    const theses = await Thesis.find({ student: req.params.studentId })
      .populate('supervisor', 'name email')
      .populate('student', 'name email');
    res.json(theses);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching theses', error: error.message });
  }
});

router.get('/supervisor/:supervisorId', auth, checkRole(['supervisor']), async (req, res) => {
  try {
    const theses = await Thesis.find({ supervisor: req.params.supervisorId })
      .populate('student', 'name email');
    res.json(theses);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching theses', error: error.message });
  }
});

export default router;